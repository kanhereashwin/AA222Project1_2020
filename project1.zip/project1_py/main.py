import numpy as np
from helpers import Simple1, Simple2, Simple3, Test
import project1


test_problem = Test()
test_problem.nolimit()

optim_history = project1.optimize(test_problem.f, test_problem.g, test_problem.x0(), test_problem.n, test_problem.count, test_problem.prob)